function greet()
            {
                let name = document.querySelector('#name').value;
                alert('Hello, ' + name + '!');
                document.querySelector('#result').innerHTML = 'What would you like to know about me ' + name + '?';
            }
            function birthday()
            {
            alert('Birthday will not include sensitive information.');
            }
            function offense()
            {
                alert('If you are offended by the next page it is YOUR problem.');
            }